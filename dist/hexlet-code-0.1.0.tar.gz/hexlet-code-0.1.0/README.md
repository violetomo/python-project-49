### Hexlet tests and linter status:
[![Actions Status](https://github.com/violetomo/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/violetomo/python-project-49/actions)
#asciinema brain-even example
https://asciinema.org/a/3ROUQF22L7nO5L1JC4px0MiT4
#asciinema brain-calc example
https://asciinema.org/a/8nBU2GHt17wenhHzws9uK6OVy
#asciinema brain-gcd example
https://asciinema.org/a/ggrHFdGUNYCbIIVaLDzQ0uwCP
#asciinema brain-progression example
https://asciinema.org/a/4mE5is7Lp0hsWpjepZXIWoHMw
