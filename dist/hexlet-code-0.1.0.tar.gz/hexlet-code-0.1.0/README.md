### Hexlet tests and linter status:
[![Actions Status](https://github.com/violetomo/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/violetomo/python-project-49/actions)
#asciinema brain-even example
https://asciinema.org/a/YsnoCQ2FFRvVKSPw5rVEG2dgs
